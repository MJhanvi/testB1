//
//  floatbotManager.h
//  floatbot
//
//  Created by Jhanvi on 05/12/17.
//  Copyright © 2017 Jhanvi. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface floatbotManager : NSObject
{
    BOOL isZOROUser;
}
@property (nonatomic) BOOL isZOROUser;
@property (nonatomic, retain) NSString *FLB_KEY;
@property (nonatomic, retain) NSString *FLB_BOT_ID;
@property (nonatomic, retain) NSString *PHONE_NUMBER_WITH_COUNTRY_CODE;
@property (nonatomic, retain) NSString *BOT_NAME;

+ (id)sharedManager;
+ (void)log:(NSString *)sLogStr;
+ (BOOL)isConnected;
- (void)setAndConnect;
+ (void)setToken:(NSData *)tokenData;
+ (void)startChatWithViewController:(UIViewController *)viewC;
@end


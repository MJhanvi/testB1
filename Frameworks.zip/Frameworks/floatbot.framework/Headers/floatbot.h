//
//  floatbot.h
//  floatbot
//
//  Created by Jhanvi on 04/12/17.
//  Copyright © 2017 Jhanvi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <floatbot/floatbotManager.h>

//! Project version number for floatbot.
FOUNDATION_EXPORT double floatbotVersionNumber;

//! Project version string for floatbot.
FOUNDATION_EXPORT const unsigned char floatbotVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <floatbot/PublicHeader.h>


